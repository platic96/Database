package Test;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		App app = App.getInstance();
		app.Run();
	}

}
